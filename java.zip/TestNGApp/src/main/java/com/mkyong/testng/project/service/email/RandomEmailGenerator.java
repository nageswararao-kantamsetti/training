package com.mkyong.testng.project.service.email;

public class RandomEmailGenerator {
	

		public String generate() {
			return "feedback@yoursite.com";
		}

}
