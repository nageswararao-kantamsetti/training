//package com.vz.service;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//
//import com.vz.domain.DLog;
//import com.vz.repository.DLRepository;
//
//@Service
//public class DLogService {
//	
//	@Autowired
//	private DLRepository dLRepository;
//	
//	public DLog saveDLogObject(DLog dLog) {
//		return dLRepository.save(dLog);
//	}
//
//	
//	
//
//}
