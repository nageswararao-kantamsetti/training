//package com.vz.repository;
//
//import org.springframework.data.repository.CrudRepository;
//import org.springframework.stereotype.Repository;
//
//import com.vz.domain.DLog;
//@Repository
//public interface DLRepository extends CrudRepository<DLog, Integer> {
//	
//	
//
//}
