import org.springframework.beans.factory.BeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.orm.hibernate5.HibernateTemplate;

public class Application {
	public static void main(String[] args) {
		ApplicationContext context  = new ClassPathXmlApplicationContext("spring.xml");
		HibernateTemplate template = context.getBean("hibernateTemplate", HibernateTemplate.class);
		
		StudentOne st = template.get(StudentOne.class, 3);
		//StudentOne st = (StudentOne) context.getBean("st");
		System.out.println(st.getCountry()+"\t"+st.getName());
		
	}

}